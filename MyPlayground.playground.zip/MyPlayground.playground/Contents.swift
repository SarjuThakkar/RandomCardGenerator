//: Playground - noun: a place where people can play

import UIKit
// This script will generate a random card from a standard deck of 52 cards
var cardType: [String] = [" of Clubs", " of Spades", " of Hearts", " of Diamonds"]
// String Array for the four types of cards, it will be used to pull a random type of card when generating a random card
var cardNum: [Int] = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
// String Array for the 13 different valued cards, it will be used to pull a random valued card when generating a random card
var ctc = cardType.count
// ctc:cardType count. This will get the number of items from the cardType array which is 4
var cnc = cardNum.count
// ctc:cardNum count. This will get the number of items from the cardNum array which is 13
let ctcu = UInt32(ctc)
// converts ctc int to uint which is 4 for the arc4random_uniform function later
let cncu = UInt32(cnc)
// converts cnc int to uint which is 13 for the arc4random_uniform function later
var randItem2 = arc4random_uniform(ctcu)
// generates random number from 0 (inclusive) to ctcu which is 4 (exclusive)
let convertRandItem2 = Int(randItem2)
// converts random number from randItem2 from uint back to int
var randItem1 = arc4random_uniform(cncu)
// generates random number from 0 (inclusive) to cncu which is 13 (exclusive)
let convertRandItem1 = Int(randItem1)
// converts random number from randItem2 from uint back to int
var firstItem = cardNum[convertRandItem1]
// takes random number from convertRandItem1 which is 0 to 12 (both inclusive) and takes the corresponding number from cardNum array. Side Note: First item in array would correspond to 0
var secondItem = cardType[convertRandItem2]
// takes random number from convertRandItem2 which is 0 to 3 (both inclusive) and takes the corresponding number from cardType array. Side Note: First item in array would correspond to 0
if(firstItem == 11){
    var firstItemString: String = "Jack"
    //if firstItem gets 11 from the cardNum array it becomes a jack
    print("Your card is the " + firstItemString + secondItem)}
    //prints your card is the whatever firstItemString equals, in this case jack, of whatever secondItem gets from the cardType array
else if(firstItem == 12){
    var firstItemString: String = "Queen"
    //if firstItem gets 12 from the cardNum array it becomes a queen
    print("Your card is the " + firstItemString + secondItem)
    //prints your card is the whatever firstItemString equals, in this case queen, of whatever secondItem gets from the cardType array
}
else if(firstItem == 13){
    var firstItemString: String = "King"
    //if firstItem gets 13 from the cardNum array it becomes a king
    print("Your card is the " + firstItemString + secondItem)}
    //prints your card is the whatever firstItemString equals, in this case king, of whatever secondItem gets from the cardType array
else if(firstItem == 14){
    var firstItemString: String = "Ace"
    //if firstItem gets 14 from the cardNum array it becomes an ace
    print("Your card is the " + firstItemString + secondItem)
    //prints your card is the whatever firstItemString equals, in this case ace, of whatever secondItem gets from the cardType array
}
else{
    var firstItemString: String = String(firstItem)
    //if firstItem gets anything beside 11, 12, 13, or 14 from cardNum array then it converts the int it gets into a string
    print("Your card is the " + firstItemString + secondItem)
    //prints your card is the "whatever firstItemString equals", in this case 2 - 10 (both inclusive), of "whatever secondItem gets from the cardType array"
}







